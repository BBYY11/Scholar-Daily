# Islam at the monastery: on infinity as subtractive truth
**人类学** - Islam at the monastery: on infinity as subtractive truth

> 中译: Islam at the monastery: on infinity as subtractive truth

## 作者简介

**Aaron F. Eldridge** - University of Toronto



## 元信息
- **作者**: Aaron F. Eldridge
- **期刊**: Journal of the Royal Anthropological Institute
- **卷期**: 
- **出版日期**: 2026-06-03
- **DOI**: https://doi.org/10.1111/1467-9655.70140
- **URL**: https://doi.org/10.1111/1467-9655.70140
- **类型**: 原创研究论文

## 一句话定位
2026-06-03 发表于 Journal of the Royal Anthropological Institute 的新作

## 导读
Based on ethnographic research at Rūm Orthodox Christian monasteries in Lebanon, the article studies scenes of Islam at the monastery as they intersect with anxious public debates on, and anthropological theorizations of, sectarianism and ‘Muslim–Christian’ relations in the Mashriq. The article demonstrates that these monastics, when speaking about Islam's imbrication with Orthodox Christianity, defer the desire for mediation and thus effect truth as what is neither language nor body. What subsequently appears is an element permanently exempted from sociological or theological mediation – points of actual infinity. To prove this, the article utilizes two modes of thinking: the so‐called ‘apophatic’ tradition of Orthodox theology and modern mathematical set theory.

## 核心概念释义

## 精读

[摘要] Based on ethnographic research at Rūm Orthodox Christian monasteries in Lebanon, the article studies scenes of Islam at the monastery as they intersect with anxious public debates on, and anthropological theorizations of, sectarianism and ‘Muslim–Christian’ relations in the Mashriq. The article demonstrates that these monastics, when speaking about Islam's imbrication with Orthodox Christianity, defer the desire for mediation and thus effect truth as what is neither language nor body. What subsequently appears is an element permanently exempted from sociological or theological mediation – points of actual infinity. To prove this, the article utilizes two modes of thinking: the so‐called ‘apophatic’ tradition of Orthodox theology and modern mathematical set theory.

## 学术对话

## 优秀评论

## 推荐指数: 0/100
（待 LLM 评分）