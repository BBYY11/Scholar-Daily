# Networks at Work: Officer Diversity, Network Segregation, and Police Misconduct
**社会学** - Networks at Work: Officer Diversity, Network Segregation, and Police Misconduct

> 中译: Networks at Work: Officer Diversity, Network Segregation, and Police Misconduct

## 作者简介

**Linda Zhao** - 未知



## 元信息
- **作者**: Linda Zhao
- **期刊**: American Journal of Sociology
- **卷期**: 
- **出版日期**: 2026-06-03
- **DOI**: https://doi.org/10.1086/742582
- **URL**: https://doi.org/10.1086/742582
- **类型**: 原创研究论文

## 一句话定位
2026-06-03 发表于 American Journal of Sociology 的新作

## 导读
（无摘要）

## 核心概念释义

## 精读

[摘要] （无摘要）

## 学术对话

## 优秀评论

## 推荐指数: 0/100
（待 LLM 评分）