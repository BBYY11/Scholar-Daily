# The Domestic Sources of International Trust
**政治学** - The Domestic Sources of International Trust

> 中译: The Domestic Sources of International Trust

## 作者简介

**Michael A. Goldfien** - Naval War College



## 元信息
- **作者**: Michael A. Goldfien, Michael F. Joseph, Roseanne W. McManus
- **期刊**: American Political Science Review
- **卷期**: 
- **出版日期**: 2026-06-08
- **DOI**: https://doi.org/10.1017/s0003055426101713
- **URL**: https://doi.org/10.1017/s0003055426101713
- **类型**: 原创研究论文

## 一句话定位
2026-06-08 发表于 American Political Science Review 的新作

## 导读
How do states overcome mistrust? Scholars argue that costly foreign policy signals build trust. But when trust is low, such as during rivalries, states are unwilling to use these signals for fear of being cheated. We argue that domestic policies can also build trust by revealing information about a state’s likelihood of cooperating internationally when there is a correlation between domestic and international preferences. We further argue that domestic policies have a distinct advantage: the value states accrue from them depends less on international reciprocation. As a result, domestic choices can reassure counterparts at moments when trust is so low that costly international signals appear prohibitively risky. We test the implications of our theory in case studies of the Cold War’s end and United States–South Korea trust-building post-coup, illuminating several phenomena the current literature struggles to explain: initial trust-building between enduring rivals, asymmetric trust-building, and trust-building through illiberal domestic policies.

## 核心概念释义

## 精读

[摘要] How do states overcome mistrust? Scholars argue that costly foreign policy signals build trust. But when trust is low, such as during rivalries, states are unwilling to use these signals for fear of being cheated. We argue that domestic policies can also build trust by revealing information about a state’s likelihood of cooperating internationally when there is a correlation between domestic and international preferences. We further argue that domestic policies have a distinct advantage: the value states accrue from them depends less on international reciprocation. As a result, domestic choices can reassure counterparts at moments when trust is so low that costly international signals appear prohibitively risky. We test the implications of our theory in case studies of the Cold War’s end and United States–South Korea trust-building post-coup, illuminating several phenomena the current literature struggles to explain: initial trust-building between enduring rivals, asymmetric trust-building, and trust-building through illiberal domestic policies.

## 学术对话

## 优秀评论

## 推荐指数: 0/100
（待 LLM 评分）