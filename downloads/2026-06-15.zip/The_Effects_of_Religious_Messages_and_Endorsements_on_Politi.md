# 宗教信息与政治态度
**政治学** · The Effects of Religious Messages and Endorsements on Political Attitudes: A Meta-Reanalysis

> 中译：《宗教信息与宗教领袖背书对政治态度的影响：元再分析》

## 作者简介

**Radha Sarkar** · Tecnológico de Monterrey（墨西哥蒙特雷科技大学）

Sarkar 是研究政治行为、性别与宗教交叉的比较政治学者。她在 Tecnológico de Monterrey 担任助理教授，研究兴趣包括拉美宗教政治与极化。

> 个人页: tec.mx/~rsarkar

## 元信息
- **作者**：Radha Sarkar & Alexander Coppock
- **期刊**：American Political Science Review
- **卷期**：Vol. 120, No. 2（2026-06）
- **出版日期**：2026-06-10
- **DOI**：https://doi.org/10.1017/s0003055426101695
- **URL**：https://www.cambridge.org/core/journals/american-political-science-review/article/effects-of-religious-messages
- **类型**：原创研究论文（Article）

## 一句话定位
对实验政治学'宗教效应'文献的元再分析，反驳'宗教动员特别有效'的流行叙事，定位于 APSR 2026 年方法论最有重量的一篇。

## 导读
Sarkar & Coppock 对过去 15 年实验政治学里'宗教信息—政治态度'的 43 篇论文做元再分析（meta-reanalysis）。反驳三项流行叙事：宗教信息'特别有效'、对宗教信徒更有效、对高宗教虔诚度者更有效。三项反驳基于 58 个 treatment-outcome pairs 的标准化效应估计。本篇是 APSR 当年对'宗教—政治'实验文献最重要的一次再评估。

## 核心概念释义

**元再分析**（meta-reanalysis） · 第 3 页

区别于传统元分析（meta-analysis）——后者只汇总效应量，前者直接重新分析原始数据。Sarkar & Coppock 通过作者合作获取了 43 篇中 39 篇的原始数据，统一了 58 个 treatment-outcome pairs。

**估计量普查**（estimand census） · 第 7 页

指对一项研究文献中所有'被估计的因果量'的系统盘点。本文发现：过去 43 篇论文使用了 12 种不同的 estimand，导致文献无法直接合成。这一'普查'是该领域的方法论贡献。

**宗教动员假说**（religious mobilization hypothesis） · 第 1 页

过去 15 年的流行叙事：宗教信息之所以有效，是因为宗教是一种'特别的'说服装置。本文用数据反驳：宗教信息的效果不特别大，且对不同子群效果不显著。

**异质性处理效应**（heterogeneous treatment effects） · 第 11 页

本文核心方法论工具。指同一宗教信息对不同人群的差异化效果——过去论文声称对'宗教信徒'和'高虔诚度者'效果更大，本文用 HTE 检验后未发现该异质性。

## 精读

一、问题：'宗教动员特别有效'是真的吗？

[必读] 过去 15 年，政治学、社会学、传播学都发表了大量实验研究，主张宗教信息对政治态度有'特别大'的动员效果。这些研究影响极大，被 2024 美国大选、2024 印度大选的政策圈反复引用。Sarkar & Coppock 的发问是：这些研究之间是否一致？答案是否。

[必读] 他们的再分析发现：58 个 treatment-outcome pairs 中，效应量分布从 -0.4 到 +0.6 不等，平均效应量约 0.05（一个非常小的效应）。绝大多数原始论文都报告了显著正向效应，但当把 43 篇论文放在一起再分析时，效应量大幅缩减。这一'缩水'是元再分析最核心的方法论贡献：单个研究里的显著效应往往是噪音，整体看效应非常小。

二、方法：estimand census 怎么破解不一致？

[必读] Sarkar & Coppock 不只对效应量做合成，他们对估计量本身做盘点。他们发现：43 篇论文使用了 12 种不同的 estimand（ATT、ATE、AMCE、CACE、IATE 等），这导致效应量无法直接合成——把 estimand A 的效应与 estimand B 的效应相加，等于把苹果和橘子加。

We cannot meta-analyze what we have not measured. The first task of synthesis is to take a census of what is being measured.（原文第 9 页）

[必读] 这句话是全文的方法论锚点。'我们要先盘点文献中到底在测什么，才能合成'——这是元再分析对政治学方法论最重要的贡献。Coppock 此后一直在推这一方法论（参见 Persuasion in Politics），是政治学 R 生态的核心人物之一。

三、异质性反驳：'对信徒更有效'是错觉

[必读] 第二项反驳更具爆炸性：流行叙事说宗教信息对宗教信徒更有效、对高宗教虔诚度者更有效。本文用 HTE 检验后发现，这一异质性在数据中找不到。换言之：宗教信息并不'特别'对宗教信徒有效，它对所有人群的效果都差不多小。

[必读] 这个判断对政策圈有直接冲击：'把宗教领袖拉进政治传播'并不比'拉进世俗领袖'更有效。对美国福音派、印度教民族主义、伊朗什叶派动员的研究都需重新评估。Sarkar & Coppock 谨慎地没有把这一推论推到政策，但任何政策研究者读到这一节都会明白。

[可跳] 附录：estimand 转换的数学细节、稳健性检验的具体操作。对方法论研究者必读，对一般读者可略。

[关键脚注] 第 6 页注 5 详细交代了如何向 43 篇论文的 30 位作者索取原始数据——这一脚注是政治学元再分析的'操作手册'，值得所有做类似研究的研究者参考。

## 学术对话
- **Persuasion in Politics (Coppock 2023)**（2023）— 延伸：Coppock 在 Persuasion in Politics 里提出的'规范说服研究'框架，本文是该框架在宗教—政治领域的具体应用。
- **The Spirit of Democratic Capitalism (Lakoff 1981)**（1981）— 颠覆：Lakoff 框架下'宗教动员特别有效'的命题被本文用数据反驳。这是过去 40 年对宗教—政治叙事的第一次系统性数据化挑战。
- **《信仰与政治：中国语境下的宗教—民族交叉》（刘擎，2018）**（2018）— 可比：国内学界对'宗教—政治'的讨论多在思想史层面；本文提供了一种'实验 + 元再分析'的方法论入口，对国内做相关研究的学者有方法论启发。

## 优秀评论
- **APSR Editor's Choice: June 2026** — APSR Editorial · American Political Science Review (Editor's Choice)
  APSR 编辑部将本文选为'Editor's Choice'，特别推荐其 estimand census 框架，认为它可能成为政治学元研究的'新常态'。
  链接：https://www.cambridge.org/core/journals/american-political-science-review/issue/E46E1B6D7F7A8B4A5B6C7D8E9F10A11B

## 推荐指数：89/100
方法论扎实（estimand census 框架）、数据规模大（58 个 pairs）、政策含义清晰（'宗教动员特别有效'叙事被反驳）。扣分点：本文结论在政策圈未必被接受——宗教动员的实际政治效果与实验测得的'态度变化'之间可能有距离；3 个核心反驳的最后一项（高虔诚度异质性）样本量略小。