# 威权韧性
**政治学** · Authoritarian Resilience in the Age of Digital Surveillance

> 中译：《威权韧性：数字监控时代的政权存续》

## 元信息
- **作者**：Karim Sadjapour
- **出版社**：Cambridge University Press
- **出版日期**：2026-06-02
- **ISBN**：978-1-108-XXXXX-X
- **页数**：356 页
- **URL**：https://www.cambridge.org/XXXXX

## 一句话定位
在比较政治学领域，对“威权衰退论”做了一次系统反驳，定位于数字威权研究的最新一波。

## 导读
Sadjapour 选取 8 个案例（伊朗、沙特、埃及、埃塞俄比亚、匈牙利、塞尔维亚、菲律宾、越南），论证数字监控技术不是威权的棺材钉，反而是它的延长命。他把 2020—2024 年的衰退论叙事系统地驳回去——这本书值得所有做政体转型的学者认真对待。

## 核心概念释义

**三重锁定**（triple lock-in） · 第 33 页

Sadjapour 的核心框架：精英锁定（co-optation）、叙事锁定（discourse）、技术锁定（surveillance）三层互锁。与 Levitsky & Way 的“竞争性威权”不同，三重锁定不强调“可竞争性”，强调三种机制的耦合。

**可量化指标体系**（operationalizable index） · 第 47 页

作者把“三重锁定”做成了可量化的指标体系。这是过去十年威权研究文献里少见的尝试——他给每个维度配了 5–8 个可观察变量，读者可以直接拿来比较。

**威权衰退论**（autocratic decline thesis） · 第 11 页

指 2020 年以来由 Treisman、Loubère、Svolik 等推动的一组论断，认为技术变化与人口结构正在终结威权的存续能力。本书是对这组论断的系统反驳。

## 精读

第二章 · 概念框架：三重锁定

[必读] Sadjapour 提出“三重锁定”概念：精英锁定（co-optation）、叙事锁定（discourse）、技术锁定（surveillance）。他用这个框架把过去散落的威权研究文献整合起来，比 Levitsky & Way 的竞争性威权框架更具操作化优势。

“威权不是一块石头，是一组通过日常重复而自我加固的锁。”（第 47 页）

[必读] 这一章的方法论意义超出了案例本身。作者把“三重锁定”做成了可量化的指标体系——这是过去十年威权研究文献里少见的尝试。对做定量比较政治学的读者尤其值得精读。

第六章 · 越南的反例价值

[必读] Sadjapour 没有回避反例。他专辟一章讨论越南——一个监控很重、但体制内有改革派的国家。这一章实际削弱了他的主论点，但他处理得诚实，值得称赞。

[可跳] 第七章 · 匈牙利。虽是案例之一，但跟既有文献重合度较高，可重点读第 2、3 节。

## 学术对话
- **The Recurrent Crisis of Authoritarianism**（2023）— 颠覆：Pepinsky 在该书中说威权正在衰退，Sadjapour 直接对话这一论断。
- **Digital Authoritarianism**（2024）— 补充：Feldstein 关注监控技术的供给端（厂商），本书关注需求端（政权的策略使用）。

## 优秀评论
- **Why Authoritarianism Persists** — Steven Levitsky · Journal of Democracy
  Levitsky 高度评价该书是近五年最值得读的威权研究，但提醒读者注意：作者对反例（越南）的处理虽诚实，但理论上的吸纳仍显不够。
  链接：https://www.journalofdemocracy.org/articles/XXXX

## 推荐指数：85/100
案例选择有策略，概念框架有锋芒；扣分点：对反例的理论吸纳不够，结论略偏决定论。