# Concealing and Revealing: Women and Embodied Exemplarity in Late Imperial Chines
**历史学** · Concealing and Revealing: Women and Embodied Exemplarity in Late Imperial Chinese Biographies

> 中译：Concealing and Revealing: Women and Embodied Exemplarity in Late Imperial Chines

## 作者简介

**Xu Ma** · 未知



## 元信息
- **作者**：Xu Ma
- **期刊**：Late imperial China
- **卷期**：Vol. 47, No. 1
- **出版日期**：2026-06-01
- **DOI**：https://doi.org/10.1353/late.2026.a991709
- **URL**：https://doi.org/10.1353/late.2026.a991709
- **类型**：原创研究论文

## 一句话定位
2026-06-01 发表于 Late imperial China 的新作

## 导读
Abstract: This article examines a distinctive subset of Qing-dynasty biographies of exemplary women that foreground forensic-style description alongside supernatural revelation. Tracing this practice to Ming precedents, especially Gui Youguang's writings, the article argues that the combined staging of the maimed female body and miraculous occurrences constituted a deliberate narrative strategy for resolving juridical and moral ambiguity surrounding women killed while resisting sexual violation. Through close textual analysis and contextualization within Qing forensic practice, judicial debates, and religious culture, the article demonstrates that graphic attention to bodily wounds functioned as a form of para-juridical evidence, transforming the injured corpse into legible proof of resistance and moral integrity. Divine dreams and posthumous miracles, meanwhile, operated as supplementary modes of validation, compensating for the perceived insufficiency of formal legal adjudication. In this sense, bodily spectacle and miracle worked in tandem not to undermine Confucian norms prescribed by the nei–wai (inner–outer) divide, but to reaffirm them through their strategic suspension under conditions of inconclusive bureaucratic and judicial judgment. Situated at the intersection of history, law, and literature, the examples studied here reveal the uneasy interweaving of moral judgment, legal reasoning, and narrative sensation in Qing biographical writing.

## 核心概念释义

## 精读

[摘要] Abstract: This article examines a distinctive subset of Qing-dynasty biographies of exemplary women that foreground forensic-style description alongside supernatural revelation. Tracing this practice to Ming precedents, especially Gui Youguang's writings, the article argues that the combined staging of the maimed female body and miraculous occurrences constituted a deliberate narrative strategy for resolving juridical and moral ambiguity surrounding women killed while resisting sexual violation. Through close textual analysis and contextualization within Qing forensic practice, judicial debates, and religious culture, the article demonstrates that graphic attention to bodily wounds functioned as a form of para-juridical evidence, transforming the injured corpse into legible proof of resistance and moral integrity. Divine dreams and posthumous miracles, meanwhile, operated as supplementary modes of validation, compensating for the perceived insufficiency of formal legal adjudication. In this sense, bodily spectacle and miracle worked in tandem not to undermine Confucian norms prescribed by the nei–wai (inner–outer) divide, but to reaffirm them through their strategic suspension under conditions of inconclusive bureaucratic and judicial judgment. Situated at the intersection of history, law, and literature, the examples studied here reveal the uneasy interweaving of moral judgment, legal reasoning, and narrative sensation in Qing biographical writing.

## 学术对话

## 优秀评论

## 推荐指数：0/100
（待 LLM 评分）