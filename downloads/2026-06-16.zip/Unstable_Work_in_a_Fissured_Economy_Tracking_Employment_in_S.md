# Unstable Work in a Fissured Economy: Tracking Employment in Subcontractor Establ
**社会学** · Unstable Work in a Fissured Economy: Tracking Employment in Subcontractor Establishments in France

> 中译：Unstable Work in a Fissured Economy: Tracking Employment in Subcontractor Establ

## 作者简介

**Clem Aeppli** · Massachusetts Institute of Technology



## 元信息
- **作者**：Clem Aeppli
- **期刊**：American Sociological Review
- **卷期**：
- **出版日期**：2026-06-10
- **DOI**：https://doi.org/10.1177/00031224261448194
- **URL**：https://doi.org/10.1177/00031224261448194
- **类型**：原创研究论文

## 一句话定位
2026-06-10 发表于 American Sociological Review 的新作

## 导读
Many jobs in the twenty-first century have become short-term, precarious, and unstable. To help explain this phenomenon, I consider the fragmentation of economic activity across networks of transacting organizations—a trend known to affect pay, but with unknown implications for the stability of work. I focus on a key part of this trend: the growing role of subcontracting. Combining research on the reasons for subcontracting with organizational theories of dependence and diversification, I argue that many subcontractor establishments face volatile demand and have few margins to cut costs other than labor. These factors compound to destabilize work for employees. Drawing on restricted-access French microdata, I show that employment at subcontractor establishments is substantially more unstable than elsewhere. I then trace this instability to key features of their organizational structure. Subcontractors employ a narrower range of occupations, are less profitable, and spend a greater share of their total expenses on labor than do non-subcontractors. Together, these attributes can account for almost two fifths of subcontractors’ excess employment instability. Finally, I show how subcontractor establishments are less able to insulate their employees from swings in demand. Following a drop in revenue, the employees of subcontractor establishments are more likely to exit than are those of non-subcontractor establishments. These findings demand a richer view of employment instability

## 核心概念释义

## 精读

[摘要] Many jobs in the twenty-first century have become short-term, precarious, and unstable. To help explain this phenomenon, I consider the fragmentation of economic activity across networks of transacting organizations—a trend known to affect pay, but with unknown implications for the stability of work. I focus on a key part of this trend: the growing role of subcontracting. Combining research on the reasons for subcontracting with organizational theories of dependence and diversification, I argue that many subcontractor establishments face volatile demand and have few margins to cut costs other than labor. These factors compound to destabilize work for employees. Drawing on restricted-access French microdata, I show that employment at subcontractor establishments is substantially more unstable than elsewhere. I then trace this instability to key features of their organizational structure. Subcontractors employ a narrower range of occupations, are less profitable, and spend a greater share of their total expenses on labor than do non-subcontractors. Together, these attributes can account for almost two fifths of subcontractors’ excess employment instability. Finally, I show how subcontractor establishments are less able to insulate their employees from swings in demand. Following a drop in revenue, the employees of subcontractor establishments are more likely to exit than are those of non-subcontractor establishments. These findings demand a richer view of employment instability, entailing not only the demise of conventional employment practices—the focus of much recent research—but also the function and structure of organizations.

## 学术对话

## 优秀评论

## 推荐指数：0/100
（待 LLM 评分）