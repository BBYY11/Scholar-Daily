# The Effects of Religious Messages and Endorsements on Political Attitudes: A Met
**政治学** · The Effects of Religious Messages and Endorsements on Political Attitudes: A Meta-Reanalysis

> 中译：The Effects of Religious Messages and Endorsements on Political Attitudes: A Met

## 作者简介

**Radha Sarkar** · Tecnológico de Monterrey



## 元信息
- **作者**：Radha Sarkar, Alexander Coppock
- **期刊**：American Political Science Review
- **卷期**：
- **出版日期**：2026-06-10
- **DOI**：https://doi.org/10.1017/s0003055426101695
- **URL**：https://doi.org/10.1017/s0003055426101695
- **类型**：原创研究论文

## 一句话定位
2026-06-10 发表于 American Political Science Review 的新作

## 导读
The experimental study of the effects of religious messages and endorsements by religious leaders on political attitudes has a relatively short history yet has coalesced around three main claims: religious treatments are especially effective because of their religious character, effects are larger for religious affiliates than nonaffiliates, and effects are larger for high religiosity types than low religiosity types. Here, we meta-reanalyze the experimental record (58 treatment-outcome pairs drawn from 43 studies reported in 26 papers) to probe the generalizability of these claims. Our findings indicate that these three headline claims do not generalize straightforwardly across contexts: effects are large in some cases and close to zero in others, and we find no evidence in favor of the claimed heterogeneities by religious affiliation or religiosity. Based on a census of the estimands in this literature, we offer suggestions for future research that would enhance commensurability and synthesis.

## 核心概念释义

## 精读

[摘要] The experimental study of the effects of religious messages and endorsements by religious leaders on political attitudes has a relatively short history yet has coalesced around three main claims: religious treatments are especially effective because of their religious character, effects are larger for religious affiliates than nonaffiliates, and effects are larger for high religiosity types than low religiosity types. Here, we meta-reanalyze the experimental record (58 treatment-outcome pairs drawn from 43 studies reported in 26 papers) to probe the generalizability of these claims. Our findings indicate that these three headline claims do not generalize straightforwardly across contexts: effects are large in some cases and close to zero in others, and we find no evidence in favor of the claimed heterogeneities by religious affiliation or religiosity. Based on a census of the estimands in this literature, we offer suggestions for future research that would enhance commensurability and synthesis.

## 学术对话

## 优秀评论

## 推荐指数：0/100
（待 LLM 评分）