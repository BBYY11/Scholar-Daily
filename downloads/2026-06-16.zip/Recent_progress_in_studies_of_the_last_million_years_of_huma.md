# Recent progress in studies of the last million years of human physical and behav
**人类学** · Recent progress in studies of the last million years of human physical and behavioural evolution

> 中译：Recent progress in studies of the last million years of human physical and behav

## 作者简介

**James; id_orcid 0000-0002-7009-5303 Cole** · University of Brighton



## 元信息
- **作者**：James; id_orcid 0000-0002-7009-5303 Cole, Eleanor Scerri, Mateja Hajdinjak
- **期刊**：Journal of the Royal Anthropological Institute
- **卷期**：
- **出版日期**：2026-06-08
- **DOI**：https://doi.org/10.1111/1467-9655.70141
- **URL**：https://doi.org/10.1111/1467-9655.70141
- **类型**：原创研究论文

## 一句话定位
2026-06-08 发表于 Journal of the Royal Anthropological Institute 的新作

## 导读
This article presents a synthesis of recent developments in the study of human evolution over the past five years. It begins with an overview of hominin species nomenclature and diversity, followed by an examination of the proposed population bottleneck ∼900,000 years ago. The discussion then turns to the ongoing debate regarding the Last Common Ancestor (LCA) of Homo sapiens , Neanderthals, and Denisovans, contextualized within patterns of hominin dispersal over the last million years. Key fossil discoveries, including Harbin, Homo luzonensis , Apidima 1, and Yunxian, are evaluated for their implications on evolutionary relationships. Finally, the paper explores recent findings related to hominin behaviour and considers their broader significance for understanding cognitive capacities in Middle to Late Pleistocene populations.

## 核心概念释义

## 精读

[摘要] This article presents a synthesis of recent developments in the study of human evolution over the past five years. It begins with an overview of hominin species nomenclature and diversity, followed by an examination of the proposed population bottleneck ∼900,000 years ago. The discussion then turns to the ongoing debate regarding the Last Common Ancestor (LCA) of Homo sapiens , Neanderthals, and Denisovans, contextualized within patterns of hominin dispersal over the last million years. Key fossil discoveries, including Harbin, Homo luzonensis , Apidima 1, and Yunxian, are evaluated for their implications on evolutionary relationships. Finally, the paper explores recent findings related to hominin behaviour and considers their broader significance for understanding cognitive capacities in Middle to Late Pleistocene populations.

## 学术对话

## 优秀评论

## 推荐指数：0/100
（待 LLM 评分）